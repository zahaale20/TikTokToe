/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiktoktoe;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import static javax.swing.BorderFactory.createEtchedBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author carso
 */
public class TikTokToe {

    private static JFrame f;
    private static JPanel mainPanel;
    private static boolean playerOne;
    private static int clicks;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        f = new JFrame("Tik Tok Toe");
        clicks = 0;
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainPanel = new JPanel(new GridLayout(3, 3));
        mainPanel.setVisible(false);
        playerOne = true;
        mainPanel.setPreferredSize(new Dimension(806, 828));
        f.setSize(806, 828);
        f.setVisible(true);
        f.setResizable(false);
        f.setLocation(557, 126);
        
        initFrame();
        f.add(mainPanel, BorderLayout.CENTER);

    }

    private static void initFrame() {
        JButton start = new JButton();
        f.add(start);
        start.setText("Start Game");
        start.setBackground(Color.white);
        start.setBorder(createEtchedBorder());
        start.setFocusable(false);
        start.setBounds(330, 400, 140, 35);
        start.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainPanel.setVisible(true);
                start.setVisible(false);
                start.setEnabled(false);
            }
        }
        );
        JLabel test = new JLabel();
        f.add(test);
        // Board

        JLabel[] labels = new JLabel[9];
        for (int i = 0; i < 9; i++) {
            labels[i] = new JLabel();
            mainPanel.add(labels[i]);
            setStyle(labels[i]);
        }

        labels[0].setIcon(new ImageIcon("gray.png"));
        labels[0].setBounds(8, 8, 250, 250);
        labels[1].setBackground(Color.white);
        labels[1].setBounds(275, 8, 250, 250);
        labels[2].setIcon(new ImageIcon("gray.png"));
        labels[2].setBounds(542, 8, 250, 250);
        labels[3].setBackground(Color.white);
        labels[3].setBounds(8, 275, 250, 250);
        labels[4].setIcon(new ImageIcon("gray.png"));
        labels[4].setBounds(275, 275, 250, 250);
        labels[5].setBackground(Color.white);
        labels[5].setBounds(542, 275, 250, 250);
        labels[6].setIcon(new ImageIcon("gray.png"));
        labels[6].setBounds(8, 542, 250, 250);
        labels[7].setBackground(Color.white);
        labels[7].setBounds(275, 542, 250, 250);
        labels[8].setIcon(new ImageIcon("gray.png"));
        labels[8].setBounds(542, 542, 250, 250);
        // main panel
    }

    private static void setStyle(JLabel j) {
        j.setBorder(createEtchedBorder());
        j.setFocusable(false);
        j.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                clicks++;
                if (clicks < 10) {
                    if (playerOne) {
                        j.setIcon(new ImageIcon("charli.jpg"));
                        j.removeMouseListener(this);
                        playerOne = false;
                    } else {
                        j.setIcon(new ImageIcon("rsz_addison.jpg"));
                        j.removeMouseListener(this);
                        playerOne = true;
                    }
                }

            }
        });
    }

}
